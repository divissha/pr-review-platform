# PRism: pull request risk, three ways

PRism reads a GitHub pull request, explains the change in plain English, and scores its risk with
**three methods at once**, then measures which method best predicts what really happened later
(reverted, bug-linked, hotfixed).

| Method | How it works | Code |
|---|---|---|
| Rule-based | Heuristics: size, sensitive files, migrations, tests added | `scoring/rule_based.py` |
| ML-based | Logistic regression trained on past labelled PRs (time-based split) | `scoring/ml_based.py`, `train_ml` |
| LLM-based | Diff sent to an LLM, returns summary + risk + reasons | `scoring/llm_based.py` |

Two modes: **live** (webhook or "Analyze PR" box) and **batch** (`collect_prs` + `run_batch` + `evaluate`).

## Quick start (about 5 minutes, no Redis, no Postgres, no API keys)

```bash
# 1. Backend
cd backend
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
python manage.py migrate
python manage.py seed_demo          # 150 synthetic labelled PRs (DEMO DATA ONLY)
python manage.py train_ml           # time-based split, saves the model + hold-out ids
python manage.py run_batch --methods rule,ml
python manage.py evaluate           # comparison table in the terminal
python manage.py runserver          # API on :8000

# 2. Frontend (new terminal)
cd frontend
npm install
npm run dev                         # http://localhost:5173  (proxies /api to :8000)
```

Run the tests: `python manage.py test`

## Using real data

1. Put `GITHUB_TOKEN` in `backend/.env` (without a token GitHub allows only 60 requests/hour).
2. `python manage.py collect_prs pallets/click --limit 200`, which stores merged PRs and labels **reverted** ones.
3. `python manage.py train_ml && python manage.py run_batch --methods rule,ml,llm && python manage.py evaluate`.
4. Add `ANTHROPIC_API_KEY` to enable the LLM scorer. Set `LLM_MAX_DIFF_CHARS` to control cost.

Labels used: `reverted` if a later revert PR points at it; other merged PRs older than 30 days are `clean`
(weak label: "no revert detected"); newer PRs stay `unknown`. Extend `label_outcomes()` for bug-linked/hotfixed.

## Live mode (webhook)

Point a GitHub repo webhook at `https://<your-host>/api/webhooks/github/` (content type JSON, event: Pull requests)
and set `GITHUB_WEBHOOK_SECRET`. For local testing use a tunnel (ngrok / cloudflared). The endpoint verifies the
HMAC signature, answers immediately, and hands the work to Celery. Set `CELERY_EAGER=0` and run
`celery -A prism worker -l info` with Redis (`docker compose up -d`).

## Layout

```
backend/
  core/      PRs, repos, comments, GitHub client, webhook, REST API, Celery tasks, collect_prs
  scoring/   the 3 scorers, shared features, pipeline, evaluation, seed_demo/train_ml/run_batch/evaluate
frontend/    React + Vite + Tailwind + Recharts: PR list, PR detail, evaluation
```

Every scorer implements one interface (`BaseScorer.score(pr) -> ScoreResult`), and `scoring/pipeline.py` runs them
for both live and batch mode. To add a fourth method, add a class and register it in `SCORERS`.

## API

`GET /api/prs/` (filters: `repo, outcome, state, q, ordering`), `GET /api/prs/<id>/`, `POST /api/prs/ingest/`,
`POST /api/prs/<id>/analyze/`, `GET|POST /api/prs/<id>/comments/`, `GET /api/repos/`,
`GET /api/evaluation/?threshold=0.5&holdout=1`, `POST /api/webhooks/github/`.

## Research design notes (for the report / viva)

* **Fair comparison:** the ML model is scored only on PRs it never trained on (`holdout=1`), and all methods are evaluated on that same set.
* **Class imbalance:** risky PRs are rare, so read precision/recall/PR-AUC, not accuracy.
* **Label noise:** "clean" means "no revert detected", which is a weak label. Say so in limitations.
* **LLM contamination:** public repos may be in the LLM's training data. Mention it, and consider newer PRs or private repos.
* **Cost:** the LLM arm costs money per PR. Use `--limit` and `--only-missing` while developing.

## Status against the 7-week plan

Done: project setup, DB schema, webhook + signature check, Celery tasks, PyGithub fetch, rule-based scorer,
ML scorer + training, LLM scorer (v1 prompt), comments API, PR list/detail/evaluation UI, batch tooling.
Still to do: GitHub OAuth login, static analysis (Bandit/ESLint), bug-linked/hotfix labels, real data
collection, evaluation on real data, deployment (Render/Railway + Vercel), the report.

Not yet exercised: live GitHub calls (`collect_prs`, `ingest`) and the LLM scorer with a real key. They are written
against the PyGithub / Anthropic SDKs but need a first run with your credentials.
