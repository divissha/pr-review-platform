import { useEffect, useState } from "react";
import Evaluation from "./Evaluation.jsx";
import PRDetail from "./PRDetail.jsx";
import PullRequests from "./PullRequests.jsx";
import { Logo } from "./parts.jsx";

function useHash() {
  const [hash, setHash] = useState(window.location.hash);
  useEffect(() => {
    const on = () => { setHash(window.location.hash); window.scrollTo(0, 0); };
    window.addEventListener("hashchange", on);
    return () => window.removeEventListener("hashchange", on);
  }, []);
  return hash;
}

export default function App() {
  const hash = useHash();
  const detail = hash.match(/^#\/pr\/(\d+)/);
  const onEval = hash.startsWith("#/evaluation");
  const link = (active) => `pb-1 ${active ? "border-b-2 border-ink font-semibold" : "text-muted hover:text-ink"}`;

  return (
    <>
      <header className="border-b border-line bg-white">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-4">
          <a href="#/" className="flex items-center gap-2 text-lg font-bold tracking-tight"><Logo /> PRism</a>
          <nav className="flex gap-6 text-sm">
            <a href="#/" className={link(!onEval)}>Pull requests</a>
            <a href="#/evaluation" className={link(onEval)}>Evaluation</a>
          </nav>
        </div>
      </header>
      <main className="mx-auto max-w-6xl px-5 py-10">
        {detail ? <PRDetail id={detail[1]} /> : onEval ? <Evaluation /> : <PullRequests />}
      </main>
    </>
  );
}
