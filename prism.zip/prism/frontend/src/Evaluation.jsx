import { useState } from "react";
import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { METHODS, api, useAsync } from "./api.js";

const METRICS = [["precision", "Precision"], ["recall", "Recall"], ["f1", "F1"], ["roc_auc", "ROC-AUC"], ["pr_auc", "PR-AUC"]];

export default function Evaluation() {
  const [threshold, setThreshold] = useState(0.5);
  const [holdout, setHoldout] = useState(true);
  const repos = useAsync(() => api.repos(), []);
  const { data, error, loading } = useAsync(
    () => api.evaluation({ threshold, holdout: holdout ? 1 : 0 }),
    [threshold, holdout]
  );
  const demo = (repos.data ?? []).some((r) => r.is_demo);

  const chart = data && METRICS.map(([k, label]) => ({
    metric: label,
    ...Object.fromEntries(data.methods.map((m) => [m.method, m[k] ?? 0])),
  }));
  const best = data && [...data.methods].filter((m) => m.roc_auc != null).sort((a, b) => b.roc_auc - a.roc_auc)[0];

  return (
    <div>
      <h1 className="text-3xl font-bold tracking-tight">Which method predicts real outcomes best?</h1>
      <p className="mt-1 max-w-2xl text-muted">
        Every method scores the same historical PRs. We compare those scores with what actually happened: reverted, bug-linked or hotfixed.
      </p>

      {demo && (
        <p className="mt-5 border-l-4 border-rule bg-white px-4 py-3 text-sm">
          This database contains synthetic demo PRs, so these numbers show that the pipeline works. They are not research results.
        </p>
      )}
      {error && <p className="mt-6 text-danger">Could not load evaluation: {error.message}</p>}

      <div className="mt-6 flex flex-wrap items-center gap-6 text-sm">
        <label className="flex items-center gap-3">
          Decision threshold <span className="font-mono">{threshold.toFixed(2)}</span>
          <input type="range" min="0.2" max="0.8" step="0.05" value={threshold} onChange={(e) => setThreshold(Number(e.target.value))} />
        </label>
        <label className="flex items-center gap-2">
          <input type="checkbox" checked={holdout} onChange={(e) => setHoldout(e.target.checked)} />
          Hold-out PRs only (fair to the ML model)
        </label>
      </div>

      {data && (
        <>
          <p className="mt-4 text-sm text-muted">
            {data.n_prs} PRs evaluated, {data.n_risky} of them risky.
            {best && <> Highest ROC-AUC: <b className="text-ink">{METHODS.find((m) => m.key === best.method).name}</b>. With few risky PRs, small gaps can be noise.</>}
          </p>

          <div className="mt-6 h-80 w-full">
            <ResponsiveContainer>
              <BarChart data={chart} margin={{ top: 8, right: 8, left: -16, bottom: 0 }}>
                <CartesianGrid vertical={false} stroke="#d8dde6" />
                <XAxis dataKey="metric" tickLine={false} />
                <YAxis domain={[0, 1]} tickLine={false} axisLine={false} />
                <Tooltip />
                <Legend />
                {METHODS.map((m) => <Bar key={m.key} dataKey={m.key} name={m.name} fill={m.key === "rule" ? "#d98e04" : m.key === "ml" ? "#6d4aff" : "#0e9f9a"} radius={[3, 3, 0, 0]} />)}
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="mt-8 overflow-x-auto">
            <table className="w-full min-w-[36rem] text-left text-sm">
              <thead className="border-b border-line text-muted">
                <tr>
                  <th className="py-2 font-medium">Method</th><th className="font-medium">PRs</th>
                  {METRICS.map(([k, l]) => <th key={k} className="font-medium">{l}</th>)}
                  <th className="font-medium">TP / FP / FN / TN</th>
                </tr>
              </thead>
              <tbody>
                {data.methods.map((m) => (
                  <tr key={m.method} className="border-b border-line">
                    <td className="py-3 font-semibold">{METHODS.find((x) => x.key === m.method).name}</td>
                    <td>{m.n}</td>
                    {METRICS.map(([k]) => <td key={k} className="tabular-nums">{m.n === 0 ? "n/a" : m[k] ?? "n/a"}</td>)}
                    <td className="font-mono text-xs">{m.tp} / {m.fp} / {m.fn} / {m.tn}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {data.methods.some((m) => m.n === 0) && (
            <p className="mt-4 text-sm text-muted">
              A method with 0 PRs has no scores yet. Run <code className="font-mono">python manage.py run_batch --methods rule,ml,llm</code> (the LLM needs ANTHROPIC_API_KEY).
            </p>
          )}
        </>
      )}
      {loading && !data && <p className="mt-6 text-muted">Loading…</p>}
    </div>
  );
}
