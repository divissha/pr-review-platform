import { useState } from "react";
import { METHODS, api, useAsync } from "./api.js";
import { DiffView, OutcomeTag, SpectrumTrack, pct } from "./parts.jsx";

function MethodColumn({ method, a }) {
  return (
    <div className="border-t-4 pt-3" style={{ borderColor: method.color }}>
      <div className="font-semibold">{method.name}</div>
      <div className="text-xs text-muted">{method.blurb}</div>
      {a && a.status === "ok" ? (
        <>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-4xl font-bold tabular-nums">{pct(a.risk)}</span>
            <span className="text-sm text-muted">{a.label} risk</span>
          </div>
          <p className="mt-2 text-sm leading-relaxed">{a.summary}</p>
          {a.reasons?.length > 0 && (
            <ul className="mt-2 list-disc space-y-1 pl-5 text-sm text-muted">
              {a.reasons.map((r, i) => <li key={i}>{r}</li>)}
            </ul>
          )}
          <div className="mt-2 text-xs text-muted">{a.model_version} · {a.latency_ms} ms</div>
        </>
      ) : (
        <p className="mt-3 text-sm text-muted">
          {a ? (a.status === "unavailable" ? a.error : `Failed: ${a.error}`) : "Not scored yet."}
        </p>
      )}
    </div>
  );
}

export default function PRDetail({ id }) {
  const [tick, setTick] = useState(0);
  const { data: pr, error, loading } = useAsync(() => api.pr(id), [id, tick]);
  const [comment, setComment] = useState({ author: "", body: "" });

  if (error) return <p className="text-danger">Could not load this PR: {error.message}</p>;
  if (loading && !pr) return <p className="text-muted">Loading…</p>;

  const rerun = async () => { await api.analyze(id); setTimeout(() => setTick((t) => t + 1), 1200); };
  const post = async (e) => {
    e.preventDefault();
    await api.addComment(id, comment.author || "anonymous", comment.body);
    setComment({ author: comment.author, body: "" });
    setTick((t) => t + 1);
  };

  return (
    <div>
      <a href="#/" className="text-sm text-muted hover:text-ink">Back to pull requests</a>
      <h1 className="mt-3 text-3xl font-bold tracking-tight">{pr.title}</h1>
      <p className="mt-1 text-muted">
        {pr.repo}#{pr.number} · {pr.author || "unknown"} · {pr.changed_files} files ·{" "}
        <span className="font-mono text-xs"><span className="text-[#1a7f4b]">+{pr.additions}</span> <span className="text-danger">−{pr.deletions}</span></span>{" "}
        · outcome: <OutcomeTag outcome={pr.outcome} />
        {pr.url && <> · <a className="underline" href={pr.url} target="_blank" rel="noreferrer">View on GitHub</a></>}
      </p>

      <section className="mt-8">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold">Three methods, one PR</h2>
          <button onClick={rerun} className="rounded-md border border-line px-3 py-1.5 text-sm hover:bg-white">Re-run scoring</button>
        </div>
        <div className="mt-3"><SpectrumTrack analyses={pr.analyses} tall /></div>
        <div className="mt-6 grid gap-8 md:grid-cols-3">
          {METHODS.map((m) => <MethodColumn key={m.key} method={m} a={pr.analyses.find((x) => x.method === m.key)} />)}
        </div>
      </section>

      {pr.body && <section className="mt-10 max-w-3xl"><h2 className="text-lg font-semibold">Description</h2><p className="mt-2 whitespace-pre-wrap text-sm leading-relaxed">{pr.body}</p></section>}

      <section className="mt-10">
        <h2 className="mb-3 text-lg font-semibold">Changes</h2>
        <DiffView files={pr.files} />
      </section>

      <section className="mt-10 max-w-2xl">
        <h2 className="text-lg font-semibold">Comments</h2>
        {pr.comments.length === 0 && <p className="mt-2 text-sm text-muted">No comments yet. Add the first note for this PR.</p>}
        {pr.comments.map((c) => (
          <div key={c.id} className="mt-3 border-l-2 border-line pl-4">
            <div className="text-sm font-semibold">{c.author} <span className="font-normal text-muted">· {new Date(c.created_at).toLocaleString()}</span></div>
            <p className="mt-1 whitespace-pre-wrap text-sm">{c.body}</p>
          </div>
        ))}
        <form onSubmit={post} className="mt-5 grid gap-2">
          <input className="w-56 rounded-md border border-line bg-white px-3 py-2 text-sm" placeholder="Your name" value={comment.author} onChange={(e) => setComment({ ...comment, author: e.target.value })} />
          <textarea className="rounded-md border border-line bg-white px-3 py-2 text-sm" rows={3} placeholder="Write a comment" value={comment.body} onChange={(e) => setComment({ ...comment, body: e.target.value })} required />
          <button className="w-fit rounded-md bg-ink px-4 py-2 text-sm font-semibold text-white hover:bg-black">Post comment</button>
        </form>
      </section>
    </div>
  );
}
