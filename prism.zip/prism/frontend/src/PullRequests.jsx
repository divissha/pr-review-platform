import { useState } from "react";
import { api, useAsync, useDebounced } from "./api.js";
import { Legend, OutcomeTag, SpectrumTrack, disagreement } from "./parts.jsx";

const inputCls = "rounded-md border border-line bg-white px-3 py-2 text-sm";

export default function PullRequests() {
  const [q, setQ] = useState("");
  const [outcome, setOutcome] = useState("");
  const [repo, setRepo] = useState("");
  const [page, setPage] = useState(1);
  const [tick, setTick] = useState(0);
  const dq = useDebounced(q);

  const repos = useAsync(() => api.repos(), []);
  const prs = useAsync(() => api.prs({ q: dq, outcome, repo, page }), [dq, outcome, repo, page, tick]);

  const [form, setForm] = useState({ repo: "", number: "" });
  const [msg, setMsg] = useState("");
  const submit = async (e) => {
    e.preventDefault();
    setMsg("Fetching and scoring…");
    try {
      await api.ingest(form.repo.trim(), Number(form.number));
      setMsg("Queued. It appears here once scoring finishes.");
      setTimeout(() => setTick((t) => t + 1), 1500);
    } catch (err) {
      setMsg(`Could not analyze: ${err.message}`);
    }
  };

  const rows = prs.data?.results ?? [];
  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Pull requests</h1>
          <p className="mt-1 max-w-xl text-muted">
            Each dot is one method’s risk estimate for that PR. When the dots spread apart, the methods disagree.
          </p>
        </div>
        <Legend />
      </div>

      <form onSubmit={submit} className="mt-8 flex flex-wrap items-center gap-2">
        <input className={`${inputCls} w-56`} placeholder="owner/repo" value={form.repo}
               onChange={(e) => setForm({ ...form, repo: e.target.value })} required />
        <input className={`${inputCls} w-24`} placeholder="PR #" inputMode="numeric" value={form.number}
               onChange={(e) => setForm({ ...form, number: e.target.value })} required />
        <button className="rounded-md bg-ink px-4 py-2 text-sm font-semibold text-white hover:bg-black">Analyze PR</button>
        <span className="text-sm text-muted">{msg}</span>
      </form>

      <div className="mt-6 flex flex-wrap gap-2">
        <input className={`${inputCls} w-64`} placeholder="Search title or author" value={q}
               onChange={(e) => { setQ(e.target.value); setPage(1); }} />
        <select className={inputCls} value={repo} onChange={(e) => { setRepo(e.target.value); setPage(1); }}>
          <option value="">All repositories</option>
          {(repos.data ?? []).map((r) => <option key={r.id} value={r.full_name}>{r.full_name}</option>)}
        </select>
        <select className={inputCls} value={outcome} onChange={(e) => { setOutcome(e.target.value); setPage(1); }}>
          <option value="">Any outcome</option>
          {["clean", "reverted", "bug_linked", "hotfixed", "unknown"].map((o) => <option key={o} value={o}>{o.replace("_", "-")}</option>)}
        </select>
      </div>

      <div className="mt-4 border-t border-line">
        {prs.error && <p className="py-6 text-danger">Could not load PRs: {prs.error.message}. Is the Django server running on port 8000?</p>}
        {!prs.loading && !prs.error && rows.length === 0 && (
          <p className="py-10 text-muted">
            No pull requests yet. Run <code className="font-mono">python manage.py seed_demo</code> for demo data, or analyze a real PR above.
          </p>
        )}
        {rows.map((p) => (
          <a key={p.id} href={`#/pr/${p.id}`}
             className="grid grid-cols-1 items-center gap-x-8 gap-y-2 border-b border-line py-4 hover:bg-white md:grid-cols-[minmax(0,1.4fr)_9rem_minmax(0,1fr)]">
            <div className="min-w-0">
              <div className="truncate font-semibold">{p.title}</div>
              <div className="mt-0.5 text-sm text-muted">
                {p.repo}#{p.number} · {p.author || "unknown"} · <OutcomeTag outcome={p.outcome} />
              </div>
            </div>
            <div className="font-mono text-xs text-muted">
              <span className="text-[#1a7f4b]">+{p.additions}</span> <span className="text-danger">−{p.deletions}</span>
              <div>{p.changed_files} {p.changed_files === 1 ? "file" : "files"}</div>
            </div>
            <div>
              <SpectrumTrack analyses={p.analyses} />
              {disagreement(p.analyses) > 0.4 && <div className="text-xs text-muted">Methods disagree</div>}
            </div>
          </a>
        ))}
      </div>

      <div className="mt-4 flex items-center justify-between text-sm text-muted">
        <span>{prs.data ? `${prs.data.count} pull requests` : ""}</span>
        <span className="flex gap-2">
          <button disabled={!prs.data?.previous} onClick={() => setPage(page - 1)} className="rounded-md border border-line px-3 py-1 enabled:hover:bg-white disabled:opacity-40">Previous</button>
          <button disabled={!prs.data?.next} onClick={() => setPage(page + 1)} className="rounded-md border border-line px-3 py-1 enabled:hover:bg-white disabled:opacity-40">Next</button>
        </span>
      </div>
    </div>
  );
}
