import { useEffect, useState } from "react";

async function req(path, opts = {}) {
  const r = await fetch(`/api${path}`, { headers: { "Content-Type": "application/json" }, ...opts });
  if (!r.ok) throw new Error((await r.text()).slice(0, 200) || r.statusText);
  return r.json();
}
const qs = (o) => new URLSearchParams(Object.entries(o).filter(([, v]) => v !== "" && v != null)).toString();
const post = (path, body) => req(path, { method: "POST", body: JSON.stringify(body) });

export const api = {
  repos: () => req("/repos/"),
  prs: (params) => req(`/prs/?${qs(params)}`),
  pr: (id) => req(`/prs/${id}/`),
  ingest: (repo, number) => post("/prs/ingest/", { repo, number }),
  analyze: (id) => post(`/prs/${id}/analyze/`, {}),
  addComment: (id, author, body) => post(`/prs/${id}/comments/`, { author, body }),
  evaluation: (params) => req(`/evaluation/?${qs(params)}`),
};

export const METHODS = [
  { key: "rule", name: "Rule-based", color: "var(--color-rule)", blurb: "Heuristics: size, sensitive files, tests" },
  { key: "ml", name: "ML-based", color: "var(--color-ml)", blurb: "Logistic regression trained on past PRs" },
  { key: "llm", name: "LLM-based", color: "var(--color-llm)", blurb: "Reads the diff and explains it" },
];

/** Tiny data hook: { data, error, loading } that refetches when deps change. */
export function useAsync(fn, deps) {
  const [state, set] = useState({ data: null, error: null, loading: true });
  useEffect(() => {
    let live = true;
    set((s) => ({ ...s, loading: true }));
    fn().then(
      (data) => live && set({ data, error: null, loading: false }),
      (error) => live && set({ data: null, error, loading: false })
    );
    return () => { live = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
  return state;
}

export function useDebounced(value, ms = 300) {
  const [v, setV] = useState(value);
  useEffect(() => { const t = setTimeout(() => setV(value), ms); return () => clearTimeout(t); }, [value, ms]);
  return v;
}
