import { METHODS } from "./api.js";

const pct = (r) => `${Math.round(r * 100)}%`;
export const isRisky = (o) => ["reverted", "bug_linked", "hotfixed"].includes(o);
export const outcomeText = (o) => o.replace("_", "-");

export function Logo({ size = 22 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" aria-hidden="true">
      <path d="M3 20 L11 4 L15 20 Z" fill="var(--color-ink)" />
      <path d="M15 8 L22 5" stroke="var(--color-rule)" strokeWidth="2" strokeLinecap="round" />
      <path d="M15 12 L22 12" stroke="var(--color-ml)" strokeWidth="2" strokeLinecap="round" />
      <path d="M15 16 L22 19" stroke="var(--color-llm)" strokeWidth="2" strokeLinecap="round" />
    </svg>
  );
}

/** The signature element: one 0-100% track, one dot per method. Spread = disagreement. */
export function SpectrumTrack({ analyses = [], tall = false }) {
  const h = tall ? 14 : 8;
  return (
    <div className="relative w-full" style={{ height: h + 14 }}>
      <div className="absolute inset-x-0 top-1/2 -translate-y-1/2 flex overflow-hidden rounded-full" style={{ height: h }}>
        <div className="bg-[#e4efe8]" style={{ width: "35%" }} />
        <div className="bg-[#f3ecd9]" style={{ width: "30%" }} />
        <div className="bg-[#f3dcd6]" style={{ width: "35%" }} />
      </div>
      {METHODS.map((m) => {
        const a = analyses.find((x) => x.method === m.key && x.status === "ok" && x.risk != null);
        if (!a) return null;
        return (
          <span
            key={m.key}
            title={`${m.name}: ${pct(a.risk)}`}
            className="absolute top-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-white shadow-sm"
            style={{ left: `${Math.min(97, Math.max(3, a.risk * 100))}%`, background: m.color, width: h + 6, height: h + 6 }}
          />
        );
      })}
    </div>
  );
}

export function Legend() {
  return (
    <div className="flex flex-wrap gap-x-5 gap-y-1 text-sm text-muted">
      {METHODS.map((m) => (
        <span key={m.key} className="inline-flex items-center gap-2">
          <span className="inline-block size-3 rounded-full" style={{ background: m.color }} />
          {m.name}
        </span>
      ))}
    </div>
  );
}

export function disagreement(analyses = []) {
  const r = analyses.filter((a) => a.status === "ok" && a.risk != null).map((a) => a.risk);
  return r.length > 1 ? Math.max(...r) - Math.min(...r) : 0;
}

export function OutcomeTag({ outcome }) {
  if (outcome === "unknown") return <span className="text-muted">not labelled</span>;
  return (
    <span className={isRisky(outcome) ? "font-semibold text-danger" : "text-muted"}>{outcomeText(outcome)}</span>
  );
}

export function DiffView({ files = [] }) {
  if (!files.length) return <p className="text-sm text-muted">No file changes stored for this PR.</p>;
  return (
    <div className="divide-y divide-line border-y border-line">
      {files.map((f, i) => (
        <details key={f.filename} open={i < 2}>
          <summary className="flex cursor-pointer items-center justify-between gap-4 py-2.5 text-sm">
            <span className="font-mono text-[13px]">{f.filename}</span>
            <span className="shrink-0 font-mono text-xs">
              <span className="text-[#1a7f4b]">+{f.additions}</span>{" "}
              <span className="text-danger">−{f.deletions}</span>
            </span>
          </summary>
          <pre className="mb-3 overflow-x-auto bg-white py-1 font-mono text-xs leading-5">
            {(f.patch || "(no patch text — binary or too large)").split("\n").map((line, j) => (
              <div
                key={j}
                className={
                  line.startsWith("+") ? "bg-[#e6f4ea] px-3"
                    : line.startsWith("-") ? "bg-[#fbe9e5] px-3"
                    : line.startsWith("@@") ? "bg-[#eef1f8] px-3 text-muted"
                    : "px-3"
                }
              >
                {line || " "}
              </div>
            ))}
          </pre>
        </details>
      ))}
    </div>
  );
}

export { pct };
